# pget

With this tool you can easily install packages from the apt repository or any other Debian repository wether you have root or not and tinker with them all in your home directory without affecting anything system wide with you don't have to go searching the file system to find your broken dependencies or snoop thru scripts to find what your looking for

# how to use

using this too is super easy just run setup.sh to move the the grab file to your home directory and makes it executable then it mods your $PATH to to allow the installed tools to be ran without having to switch directorys so instead of “./package_name” you can just run “package_name”

after this is done installing packages is easy just ./pget “package_to_install”

# example
example: ./pget xonsh

# use cases
this tool is mainly focused on debian package developers and such but also with the mindest of a security person
this tool makes its easy for pentesters who get non root control over a server but need to intsall packages 
PLEASE USE THIS TOOL FOR GOOD 





#DontBeAskid

# also 

if you like it please consider staring it and following me :-) for more cool stuff i have good ideas sometimes 
